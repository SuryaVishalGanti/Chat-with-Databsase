import sqlite3

# Connecting to SQLite database (creates "student.db" if it doesn't exist)
connection = sqlite3.connect("student.db")

# Create a cursor object to execute SQL commands
cursor = connection.cursor()

# Table creation (includes IF NOT EXISTS to prevent errors if it already exists)
table_info = """
CREATE TABLE IF NOT EXISTS Student (
    NAME TEXT, 
    SECTION TEXT, 
    YOJ INT,
    COMPANY TEXT
);
"""

cursor.execute(table_info)

# Inserting multiple records using executemany()
students_data = [
    ("Surya Vishal", "Data Science", 2024, "Tekworks"),
    ("Nitish", "Data Science", 2024, "Symphonize"),
    ("Ram Charan", "Data Science", 2025, "Symphonize"),
    ("Pradeep", "Full Stack", 2023, "Bitlabs"),
    ("Vineetha", "Full Stack", 2023, "Bitlabs"),
    ("Anjali Sharma", "Data Science", 2025, "TCS"),
    ("Rohit Mehta", "Cyber Security", 2024, "Infosys"),
    ("Sneha Reddy", "Full Stack", 2024, "Capgemini"),
    ("Abhishek Yadav", "AI & ML", 2023, "Google"),
    ("Sandeep Kumar", "Cyber Security", 2025, "Microsoft"),
    ("Neha Verma", "AI & ML", 2024, "Amazon"),
    ("Arjun Kapoor", "Cloud Computing", 2023, "IBM"),
    ("Priyanka Mishra", "Cloud Computing", 2024, "Accenture"),
    ("Ravi Teja", "Full Stack", 2025, "Deloitte"),
    ("Swetha Nair", "Cyber Security", 2023, "Cisco"),
    ("Manoj Singh", "Data Science", 2025, "HCL"),
    ("Aditi Rao", "Cloud Computing", 2024, "Oracle"),
    ("Varun Dhawan", "AI & ML", 2025, "Facebook"),
    ("Megha Agarwal", "Cyber Security", 2023, "Wipro"),
    ("Sahil Khan", "Full Stack", 2024, "Zoho"),
    ("Rajat Sharma", "Data Science", 2025, "TCS"),
    ("Alok Verma", "Cyber Security", 2023, "Microsoft"),
    ("Kriti Sen", "Full Stack", 2024, "Capgemini"),
    ("Anil Kumar", "AI & ML", 2025, "Google"),
    ("Simran Kaur", "Cloud Computing", 2023, "IBM"),
    ("Yash Gupta", "Data Science", 2024, "Tekworks"),
    ("Pooja Sharma", "Full Stack", 2023, "Bitlabs"),
    ("Aman Yadav", "AI & ML", 2025, "Amazon"),
    ("Vikram Singh", "Cloud Computing", 2024, "Accenture"),
    ("Neetu Kapoor", "Cyber Security", 2023, "Cisco"),
    ("Rishabh Pant", "Full Stack", 2025, "Deloitte"),
    ("Kavita Mehta", "AI & ML", 2024, "Facebook"),
    ("Sourabh Jain", "Data Science", 2023, "Wipro"),
    ("Rajesh Khanna", "Full Stack", 2024, "Zoho"),
    ("Naina Sharma", "Cyber Security", 2025, "Microsoft"),
    ("Tushar Raj", "AI & ML", 2023, "Google"),
    ("Avneet Kaur", "Cloud Computing", 2024, "Oracle"),
    ("Ishaan Awasthi", "Data Science", 2025, "HCL"),
    ("Meera Chopra", "Full Stack", 2024, "Bitlabs"),
    ("Krishna Das", "AI & ML", 2023, "Amazon"),
    ("Puneet Singh", "Cloud Computing", 2025, "Accenture"),
    ("Trisha Krishnan", "Cyber Security", 2024, "Cisco"),
    ("Dinesh Reddy", "Data Science", 2023, "TCS"),
    ("Sonia Sharma", "Full Stack", 2024, "Capgemini"),
    ("Vishal Anand", "AI & ML", 2025, "Google"),
    ("Zoya Khan", "Cyber Security", 2023, "Microsoft"),
    ("Karthik Raju", "Cloud Computing", 2024, "Oracle"),
    ("Ravi Kumar", "Data Science", 2025, "Symphonize"),
    ("Anusha Reddy", "Full Stack", 2024, "Zoho"),
    ("Harshita Mehta", "Cyber Security", 2023, "Wipro"),
    ("Akash Sharma", "Data Science", 2024, "Tekworks"),
    ("Shreya Kapoor", "AI & ML", 2025, "Facebook"),
    ("Gaurav Singh", "Cloud Computing", 2023, "IBM"),
    ("Isha Nair", "Full Stack", 2024, "Bitlabs"),
    ("Vikash Reddy", "Cyber Security", 2025, "Microsoft"),
    ("Nikhil Verma", "AI & ML", 2023, "Amazon"),
    ("Aisha Khurana", "Cloud Computing", 2024, "Accenture"),
    ("Karan Johar", "Data Science", 2025, "TCS"),
    ("Deepika Sen", "Full Stack", 2023, "Capgemini"),
    ("Pratham Mehta", "Cyber Security", 2024, "Infosys"),
    ("Ramesh Gupta", "AI & ML", 2025, "Google"),
    ("Saniya Roy", "Cloud Computing", 2023, "IBM"),
    ("Tarun Das", "Full Stack", 2024, "Zoho"),
    ("Madhavi Rao", "Data Science", 2025, "HCL"),
    ("Aarav Sharma", "Cyber Security", 2023, "Wipro"),
    ("Sonali Desai", "AI & ML", 2024, "Amazon"),
    ("Vivek Anand", "Cloud Computing", 2025, "Accenture"),
    ("Ruchi Patel", "Data Science", 2024, "Symphonize")
]

# Insert records in bulk
cursor.executemany("INSERT INTO Student (NAME, SECTION, YOJ, COMPANY) VALUES (?, ?, ?, ?)", students_data)

# Display all the records
print("The Inserted records are:")
data = cursor.execute("SELECT * FROM Student")
for row in data:
    print(row)

# Commit changes and close connection
connection.commit()
connection.close()
